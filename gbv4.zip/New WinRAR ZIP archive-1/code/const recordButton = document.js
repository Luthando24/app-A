const recordButton = document.querySelector ("#record");
const stopButton = document.querySelector ("#stop");
recordButton.addEventListener("click", () =>{
record()

})
stopButton.addEventListener("click", () =>{
record()

})
let mic,recorder,SoundFile,blob;

let status = 0;

function setup () {

mic = new p5.AudioIn();
recorder = new p5.SoundRecorder();
SoundFile = new p5.SoundFile;
recorder.setInput(mic);
}

function record(){
mic.start();
recorder.record(SoundFile);
stopButton.ClassList.remove("d-none");
recordButton.ClassList.add("d-none");
}
function stop{
mic.stop();
recorder.stop();
SoundFile.play();

stopButton.ClassList.add("d-none");
record.ClassList.remove("d-none");

}